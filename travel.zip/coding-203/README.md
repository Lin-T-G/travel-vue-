## 升级至 Vue CLI 4.3 版本后的项目

### 项目依赖安装
```
npm install
```

### 本地开发
```
npm run serve
```

### 打包编译
```
npm run build
```

### 自定义配置项
参考 [配置项文档](https://cli.vuejs.org/config/).
